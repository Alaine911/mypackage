# my packages
This library was created as an example of how to publish your own package

# Building this package locally
'python setup.py sdist'

#Installing this package from GitHub
'pip install git+https://github.com/James-leslie/example-python-package.git'
#updating this package from GitHub
'pip install --upgrade git+https://github.com/James-Leslie/example-python-package.git'
